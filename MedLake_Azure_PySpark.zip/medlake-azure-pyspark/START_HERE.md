# Start Here

1. Read `README.md`.
2. Run the pure-Python quality checks.
3. Review `docs/ARCHITECTURE.md`.
4. Provision Azure resources from `infra/terraform/`.
5. Upload synthetic sample data to the ADLS landing filesystem.
6. Create the Unity Catalog catalog/schemas.
7. Configure Key Vault-backed secrets for Event Hubs.
8. Replace `REPLACE_ME` values in `databricks.yml`.
9. Validate and deploy the bundle.
10. Run the batch pipeline.
11. Publish synthetic Event Hubs events and run the streaming job.
12. Add only real screenshots/metrics to GitHub.
