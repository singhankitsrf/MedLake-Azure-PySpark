-- Run with appropriate Unity Catalog permissions.
CREATE CATALOG IF NOT EXISTS medlake;
CREATE SCHEMA IF NOT EXISTS medlake.bronze;
CREATE SCHEMA IF NOT EXISTS medlake.silver;
CREATE SCHEMA IF NOT EXISTS medlake.gold;
