import os
from medlake.spark_transforms import add_quality_flags, deduplicate_batch, normalize_events

catalog = os.getenv("MEDLAKE_CATALOG", "medlake")
source = f"{catalog}.bronze.screening_events_raw"
valid_target = f"{catalog}.silver.screening_events"
quarantine_target = f"{catalog}.silver.screening_events_quarantine"

df = spark.table(source)
curated = deduplicate_batch(add_quality_flags(normalize_events(df)))

valid = curated.filter("_is_valid = true").drop("_quality_errors", "_is_valid")
bad = curated.filter("_is_valid = false")

valid.write.format("delta").mode("overwrite").option(
    "overwriteSchema", "true"
).saveAsTable(valid_target)

bad.write.format("delta").mode("overwrite").option(
    "overwriteSchema", "true"
).saveAsTable(quarantine_target)
