import os
from pyspark.sql import functions as F

catalog = os.getenv("MEDLAKE_CATALOG", "medlake")
patient_path = os.environ["MEDLAKE_PATIENT_PATH"]
facility_path = os.environ["MEDLAKE_FACILITY_PATH"]

patients = (
    spark.read.option("header", True).option("inferSchema", True).csv(patient_path)
    .dropDuplicates(["patient_id"])
    .withColumn("_loaded_at", F.current_timestamp())
)

facilities = (
    spark.read.option("header", True).option("inferSchema", True).csv(facility_path)
    .dropDuplicates(["facility_id"])
    .withColumn("_loaded_at", F.current_timestamp())
)

patients.write.format("delta").mode("overwrite").option(
    "overwriteSchema", "true"
).saveAsTable(f"{catalog}.silver.dim_patient")

facilities.write.format("delta").mode("overwrite").option(
    "overwriteSchema", "true"
).saveAsTable(f"{catalog}.silver.dim_facility")
