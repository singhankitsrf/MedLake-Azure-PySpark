import os
from pyspark.sql import functions as F

catalog = os.getenv("MEDLAKE_CATALOG", "medlake")
bronze_schema = "bronze"
checkpoint_path = f"{os.environ['MEDLAKE_CHECKPOINT_BASE'].rstrip('/')}/eventhubs-screening-events"

bootstrap_servers = dbutils.secrets.get(
    scope="medlake-kv", key="eventhub-bootstrap-servers"
)
eventhub_name = dbutils.secrets.get(scope="medlake-kv", key="eventhub-name")
sasl_password = dbutils.secrets.get(
    scope="medlake-kv", key="eventhub-sasl-password"
)

target = f"{catalog}.{bronze_schema}.screening_events_stream"

jaas = (
    'kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required '
    f'username="$ConnectionString" password="{sasl_password}";'
)

stream = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", bootstrap_servers)
    .option("subscribe", eventhub_name)
    .option("kafka.security.protocol", "SASL_SSL")
    .option("kafka.sasl.mechanism", "PLAIN")
    .option("kafka.sasl.jaas.config", jaas)
    .option("startingOffsets", "latest")
    .load()
    .select(
        F.col("timestamp").alias("_eventhub_ts"),
        F.col("partition").alias("_eventhub_partition"),
        F.col("offset").alias("_eventhub_offset"),
        F.col("value").cast("string").alias("json_payload"),
    )
)

query = (
    stream.writeStream
    .format("delta")
    .option("checkpointLocation", checkpoint_path)
    .outputMode("append")
    .toTable(target)
)

query.awaitTermination()
