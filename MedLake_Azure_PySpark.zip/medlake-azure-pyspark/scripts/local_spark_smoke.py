from __future__ import annotations
import json
from pathlib import Path

def main():
    from pyspark.sql import SparkSession

    spark = (
        SparkSession.builder
        .master("local[2]")
        .appName("medlake-local-smoke")
        .getOrCreate()
    )
    df = spark.read.json("data/sample_screening_events.jsonl")
    print("rows=", df.count())
    print("columns=", sorted(df.columns))
    spark.stop()

if __name__ == "__main__":
    main()
