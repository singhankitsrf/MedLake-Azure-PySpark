from __future__ import annotations
import argparse, json
from collections import Counter
from medlake.contracts import validate_event_dict

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", default="data/synthetic_screening_events.jsonl")
    args = ap.parse_args()

    counts = Counter()
    seen = set()
    total = 0
    with open(args.path, encoding="utf-8") as f:
        for line in f:
            total += 1
            event = json.loads(line)
            for error in validate_event_dict(event):
                counts[error] += 1
            event_id = event.get("event_id")
            if event_id in seen:
                counts["duplicate_event_id"] += 1
            seen.add(event_id)

    print(f"rows={total}")
    for name, count in counts.most_common():
        print(f"{name}={count}")

if __name__ == "__main__":
    main()
