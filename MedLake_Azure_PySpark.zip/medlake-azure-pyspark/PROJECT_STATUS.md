# Project Status

## Included

- PySpark reusable transformations;
- Databricks Auto Loader Bronze ingestion;
- Azure Event Hubs Structured Streaming path;
- Delta Lake Bronze/Silver/Gold design;
- quality quarantine;
- duplicate handling;
- schema-drift fixture;
- Gold KPI marts;
- Unity Catalog SQL;
- Terraform for Azure infrastructure;
- Azure Data Factory orchestration template;
- Declarative Automation Bundle with Python wheel artifact;
- GitHub Actions CI and OIDC deployment workflows;
- synthetic dataset and data-quality profiler.

## Local validation performed

- YAML parsing: **PASS**
- Python compilation: **PASS**
- Unit tests: **7 passed**
- clean CI data contract: **PASS**

The full synthetic dataset intentionally contains invalid and duplicate rows so
the Silver quarantine/deduplication design has realistic failure modes.

## Cloud-dependent validation not claimed

This environment is not connected to the user's Azure subscription or Databricks
workspace. Therefore Azure Terraform apply, live Event Hubs ingestion, Databricks
bundle deployment, Spark performance benchmarks and Azure cost numbers must be
generated in the user's own development cloud environment.
