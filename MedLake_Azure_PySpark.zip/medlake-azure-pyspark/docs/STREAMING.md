# Streaming Design

Azure Event Hubs is consumed through its Kafka-compatible endpoint from Spark
Structured Streaming.

Important operational concerns demonstrated:
- event partition/offset metadata;
- durable checkpointing;
- append-only bronze storage;
- secret retrieval rather than hard-coded connection strings;
- independent batch and streaming bronze tables.

For production, add:
- dead-letter strategy for malformed payloads;
- consumer lag monitoring;
- replay/runbook procedures;
- explicit event-time watermarks for stateful aggregations;
- load testing at the expected partition/throughput scale.
