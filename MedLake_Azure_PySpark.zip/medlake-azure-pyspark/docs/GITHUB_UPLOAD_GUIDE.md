# GitHub Upload Guide

## Repository name

`medlake-azure-pyspark`

Recommended description:

`Azure Databricks + PySpark lakehouse: ADLS Gen2, Delta medallion ETL, Auto Loader, Event Hubs streaming, data-quality quarantine, Terraform and OIDC CI/CD.`

## First local validation

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install:

```bash
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

Run:

```bash
python scripts/check_data_contract.py --path data/ci_valid_events.jsonl
ruff check src scripts tests
mypy src
pytest -q
```

For local Spark smoke testing:

```bash
pip install -e ".[spark]"
python scripts/local_spark_smoke.py
```

## Create the Git repository

```bash
git init
git branch -M main
git add .
git status
git commit -m "feat: launch MedLake Azure PySpark lakehouse"
```

Create a public GitHub repository named `medlake-azure-pyspark`, then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/medlake-azure-pyspark.git
git push -u origin main
```

## Recommended topics

`azure`, `pyspark`, `databricks`, `delta-lake`, `data-engineering`,
`lakehouse`, `adls-gen2`, `event-hubs`, `structured-streaming`,
`terraform`, `data-factory`, `github-actions`, `medallion-architecture`,
`healthcare-data`

## GitHub deployment variables

For Azure infrastructure OIDC:
- `AZURE_CLIENT_ID`
- `AZURE_TENANT_ID`
- `AZURE_SUBSCRIPTION_ID`

For Databricks OIDC:
- `DATABRICKS_HOST`
- `DATABRICKS_CLIENT_ID`

Store them as **environment/repository variables**, not source code.

## Before portfolio screenshots

Deploy only into your own development Azure subscription. Then add genuine:
- Databricks job graph screenshot;
- Bronze/Silver/Gold table screenshots;
- Event Hubs ingress evidence;
- quarantine counts;
- Gold KPI query;
- GitHub Actions deployment result;
- Azure cost snapshot for the demo;
- Spark UI screenshot for one meaningful transformation.

Do not invent throughput or cost figures.
