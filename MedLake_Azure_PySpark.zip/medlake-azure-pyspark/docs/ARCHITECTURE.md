# Architecture

```mermaid
flowchart TB
    subgraph SOURCES["Sources"]
      FILES[Batch JSON / CSV]
      EH[Azure Event Hubs]
    end

    subgraph INGEST["Ingestion"]
      AUTO[Databricks Auto Loader]
      KAFKA[Structured Streaming<br/>Kafka-compatible Event Hubs endpoint]
    end

    subgraph LAKE["ADLS Gen2 + Delta Lake"]
      BRONZE[(Bronze<br/>raw + rescued data)]
      SILVER[(Silver<br/>validated + deduplicated)]
      QUAR[(Silver quarantine)]
      GOLD[(Gold<br/>KPIs + data products)]
    end

    subgraph PLATFORM["Platform"]
      DBX[Azure Databricks]
      ADF[Azure Data Factory]
      KV[Azure Key Vault]
      MON[Azure Monitor / Log Analytics]
    end

    FILES --> AUTO --> BRONZE
    EH --> KAFKA --> BRONZE
    BRONZE --> SILVER
    BRONZE --> QUAR
    SILVER --> GOLD
    DBX --> AUTO
    DBX --> KAFKA
    ADF --> DBX
    KV --> DBX
    DBX --> MON
```

## Data layers

### Bronze
Immutable/raw ingestion, source metadata, `_rescued_data`, schema evolution and
stream checkpoints.

### Silver
Normalized timestamps/types, exact event-id deduplication, quality validation,
quarantine, reference dimensions and analytics-ready detail.

### Gold
Facility/day KPIs, referral rates, class mix, network summaries and data-quality
observability tables.

## Operational pattern

The repository intentionally supports both:
- **batch/incremental files** through Auto Loader;
- **real-time events** through Event Hubs' Kafka-compatible endpoint.
