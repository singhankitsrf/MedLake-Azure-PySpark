# Data Quality Strategy

Silver-layer validation treats quality as a first-class data product concern.

Current rules:
- event ID required;
- patient ID required;
- facility ID required;
- model confidence in [0,1];
- image quality score in [0,1].

Bad rows are **quarantined**, not silently dropped.

The synthetic dataset deliberately contains:
- null facility IDs;
- null patient IDs;
- invalid confidence values;
- duplicate event IDs;
- a schema-drift file containing new fields.

This gives the project realistic data-engineering failure modes to demonstrate.
