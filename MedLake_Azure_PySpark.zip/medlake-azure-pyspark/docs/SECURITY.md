# Security and Governance

The reference implementation is structured so credentials are not committed.

Recommended production controls:
- Microsoft Entra workload identities;
- GitHub OIDC for Azure and Databricks deployments;
- Azure Key Vault for Event Hubs credentials;
- ADLS Gen2 RBAC and ACLs;
- Unity Catalog for table/catalog governance;
- private networking/private endpoints where required;
- diagnostic logs into Log Analytics;
- environment-specific Databricks deployment targets;
- no real patient data in this public repository.

The included data are synthetic.
