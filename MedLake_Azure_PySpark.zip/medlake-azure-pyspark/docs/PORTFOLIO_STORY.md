# Recruiter / Interview Story

## 30-second pitch

“I built an Azure healthcare lakehouse with PySpark and Delta Lake supporting
both batch and real-time data. Auto Loader incrementally ingests files from ADLS
Gen2, Event Hubs feeds Structured Streaming, Silver applies data-quality and
quarantine rules, and Gold publishes operational KPIs. Azure infrastructure is
Terraform-managed and Databricks jobs are deployed through Declarative
Automation Bundles using OIDC-based GitHub Actions.”

## Strong resume bullets

- Architected a PySpark/Delta Lake medallion platform on Azure Databricks and
  ADLS Gen2, integrating incremental Auto Loader ingestion and real-time Event
  Hubs streams.

- Implemented Silver-layer schema normalization, duplicate handling, data-quality
  quarantine and Gold-layer KPI marts for scalable analytics and downstream AI.

- Automated Azure infrastructure and Databricks job deployment with Terraform,
  Declarative Automation Bundles and GitHub Actions using federated OIDC
  authentication.

## Interview themes

- PySpark transformations and shuffles
- Structured Streaming
- Event Hubs/Kafka semantics
- Delta Lake
- Bronze/Silver/Gold
- idempotency and replay
- data quality and quarantine
- schema drift
- ADLS Gen2
- Unity Catalog
- Terraform
- Data Factory orchestration
- CI/CD for data platforms
- Azure cost/performance tradeoffs
