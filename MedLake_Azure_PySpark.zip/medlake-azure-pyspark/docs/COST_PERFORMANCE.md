# Cost and Performance Strategy

## Cost controls
- use job clusters rather than permanently running development clusters;
- use autoscaling/appropriate worker counts for production;
- terminate idle interactive compute;
- keep streaming and batch jobs separate so each can scale independently;
- use ADLS lifecycle policies for archive data;
- retain raw Bronze so expensive downstream layers can be rebuilt without
  re-ingesting from upstream systems.

## Performance
- write Delta tables rather than repeatedly scanning raw JSON;
- incrementally ingest files through Auto Loader;
- compact/optimize tables only when workload evidence justifies it;
- avoid premature partitioning on high-cardinality keys;
- build Gold tables around actual query patterns.

Benchmark with production-like volumes before committing to tuning parameters.
