# Synthetic Data

This repository contains synthetic healthcare operational data only.

- `synthetic_screening_events.jsonl`: intentionally dirty full demo dataset.
- `sample_screening_events.jsonl`: small intentionally dirty sample.
- `ci_valid_events.jsonl`: clean fixture used by CI data-contract checks.
- `schema_drift_events.jsonl`: adds `firmware_version` and
  `ambient_light_score` to demonstrate schema drift.
- `synthetic_patients.csv`: synthetic patient reference attributes.
- `synthetic_facilities.csv`: synthetic facility dimension.

Run:

```bash
python scripts/profile_data_quality.py
```

to see the intentional quality defects.
